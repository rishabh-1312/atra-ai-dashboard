import React from "react";
import { Card, CardContent } from "./components/ui/card";
import { MapContainer, TileLayer } from "react-leaflet";
import "leaflet/dist/leaflet.css";

function App() {
  return (
    <div className="App">
      <Card>
        <CardContent>
          <h1>SATRA AI Dashboard</h1>
          <MapContainer center={[20.5937, 78.9629]} zoom={5} style={{ height: "400px", width: "100%" }}>
            <TileLayer url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png" />
          </MapContainer>
        </CardContent>
      </Card>
    </div>
  );
}
export default App;
